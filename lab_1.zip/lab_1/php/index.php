<?php
echo "This is the /php route!";
?>
